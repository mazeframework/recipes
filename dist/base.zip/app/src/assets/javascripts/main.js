import Maze from 'maze'
